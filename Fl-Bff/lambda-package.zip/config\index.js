"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = __importDefault(require("lodash"));
const path_1 = require("path");
let config = {
    viewDir: (0, path_1.join)(__dirname, "..", "views"),
    staticDir: (0, path_1.join)(__dirname, "..", "assets"),
    port: 8081,
    memoryFlag: false,
};
if (process.env.NODE_ENV === "development") {
    let localConfig = {
        port: 8081,
    };
    config = lodash_1.default.assignIn(config, localConfig);
}
if (process.env.NODE_ENV === "production") {
    let prodConfig = {
        port: 8082,
        memoryFlag: "memory",
    };
    config = lodash_1.default.assignIn(config, prodConfig);
}
exports.default = config;
