"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const awilix_koa_1 = require("awilix-koa");
let IndexController = class IndexController {
    async actionList(ctx) {
        const data = await ctx.render("index", {
            data: "服务端数据",
        });
        ctx.body = data;
    }
};
__decorate([
    (0, awilix_koa_1.GET)()
], IndexController.prototype, "actionList", null);
IndexController = __decorate([
    (0, awilix_koa_1.route)("/")
], IndexController);
exports.default = IndexController;
