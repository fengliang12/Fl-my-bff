"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ApiServices {
    getInfo() {
        return new Promise((resolve, reject) => {
            resolve({
                item: "我是后台数据",
                result: [11],
            });
        });
    }
}
exports.default = ApiServices;
