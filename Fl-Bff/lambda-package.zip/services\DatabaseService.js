"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const ormconfig_1 = require("../ormconfig");
const User_1 = require("../entities/User");
class DatabaseService {
    static instance;
    userRepository;
    isInitialized = false;
    constructor() {
        // 私有构造函数，防止直接实例化
    }
    static getInstance() {
        if (!DatabaseService.instance) {
            DatabaseService.instance = new DatabaseService();
        }
        return DatabaseService.instance;
    }
    async initDatabase() {
        try {
            if (!this.isInitialized) {
                await ormconfig_1.AppDataSource.initialize();
                this.userRepository = ormconfig_1.AppDataSource.getRepository(User_1.User);
                this.isInitialized = true;
                console.log('PostgreSQL数据库连接成功');
            }
        }
        catch (error) {
            console.error('数据库连接失败:', error);
            throw error;
        }
    }
    async ensureInitialized() {
        if (!this.isInitialized) {
            await this.initDatabase();
        }
    }
    async getAllFormData() {
        try {
            await this.ensureInitialized();
            const users = await this.userRepository.find({
                order: { createdAt: 'DESC' }
            });
            return users.map(user => ({
                id: user.id,
                name: user.name,
                email: user.email,
                created_at: user.createdAt.toISOString(),
                updated_at: user.updatedAt.toISOString()
            }));
        }
        catch (error) {
            console.error('获取表单数据失败:', error);
            throw error;
        }
    }
    async getFormDataById(id) {
        try {
            await this.ensureInitialized();
            const user = await this.userRepository.findOne({ where: { id } });
            if (!user)
                return null;
            return {
                id: user.id,
                name: user.name,
                email: user.email,
                created_at: user.createdAt.toISOString(),
                updated_at: user.updatedAt.toISOString()
            };
        }
        catch (error) {
            console.error('获取表单数据失败:', error);
            throw error;
        }
    }
    async createFormData(data) {
        try {
            await this.ensureInitialized();
            const user = new User_1.User();
            user.name = data.name;
            user.email = data.email;
            const savedUser = await this.userRepository.save(user);
            return {
                id: savedUser.id,
                name: savedUser.name,
                email: savedUser.email,
                created_at: savedUser.createdAt.toISOString(),
                updated_at: savedUser.updatedAt.toISOString()
            };
        }
        catch (error) {
            console.error('创建表单数据失败:', error);
            throw error;
        }
    }
    async updateFormData(id, data) {
        try {
            await this.ensureInitialized();
            const user = await this.userRepository.findOne({ where: { id } });
            if (!user)
                return null;
            user.name = data.name;
            user.email = data.email;
            const updatedUser = await this.userRepository.save(user);
            return {
                id: updatedUser.id,
                name: updatedUser.name,
                email: updatedUser.email,
                created_at: updatedUser.createdAt.toISOString(),
                updated_at: updatedUser.updatedAt.toISOString()
            };
        }
        catch (error) {
            console.error('更新表单数据失败:', error);
            throw error;
        }
    }
    async deleteFormData(id) {
        try {
            await this.ensureInitialized();
            const result = await this.userRepository.delete(id);
            return result.affected !== undefined && result.affected > 0;
        }
        catch (error) {
            console.error('删除表单数据失败:', error);
            throw error;
        }
    }
    async close() {
        try {
            if (this.isInitialized && ormconfig_1.AppDataSource.isInitialized) {
                await ormconfig_1.AppDataSource.destroy();
                this.isInitialized = false;
                console.log('数据库连接已关闭');
            }
        }
        catch (error) {
            console.error('关闭数据库连接失败:', error);
            throw error;
        }
    }
}
const databaseServiceInstance = DatabaseService.getInstance();
module.exports = databaseServiceInstance;
exports.default = databaseServiceInstance;
