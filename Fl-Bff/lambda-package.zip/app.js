"use strict";
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (
          !desc ||
          ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)
        ) {
          desc = {
            enumerable: true,
            get: function () {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
      }
    : function (o, v) {
        o["default"] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  (function () {
    var ownKeys = function (o) {
      ownKeys =
        Object.getOwnPropertyNames ||
        function (o) {
          var ar = [];
          for (var k in o)
            if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
          return ar;
        };
      return ownKeys(o);
    };
    return function (mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null)
        for (var k = ownKeys(mod), i = 0; i < k.length; i++)
          if (k[i] !== "default") __createBinding(result, mod, k[i]);
      __setModuleDefault(result, mod);
      return result;
    };
  })();
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule ? mod : { default: mod };
  };
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const dotenv = __importStar(require("dotenv"));
const awilix_1 = require("awilix");
const awilix_koa_1 = require("awilix-koa");
const koa_1 = __importDefault(require("koa"));
// 加载环境变量
dotenv.config();
const config_1 = __importDefault(require("./config"));
const koa_swig_1 = __importDefault(require("koa-swig")); // node的渲染模板
const co_1 = __importDefault(require("co"));
const koa_static_1 = __importDefault(require("koa-static"));
const koa2_connect_history_api_fallback_1 = __importDefault(
  require("koa2-connect-history-api-fallback")
);
const cors_1 = __importDefault(require("@koa/cors"));
const koa_bodyparser_1 = __importDefault(require("koa-bodyparser"));
const DatabaseService_1 = __importDefault(
  require("./services/DatabaseService")
);
const container = (0, awilix_1.createContainer)();
// 手动注册DatabaseService单例
container.register({
  databaseService: {
    resolve: () => DatabaseService_1.default,
    lifetime: awilix_1.Lifetime.SINGLETON,
  },
});
// 加载其他服务（排除DatabaseService）
container.loadModules([`${__dirname}/services/*.js`], {
  formatName: "camelCase",
  resolverOptions: {
    lifetime: awilix_1.Lifetime.SCOPED,
  },
});
const app = new koa_1.default();
const { port, viewDir, memoryFlag, staticDir } = config_1.default;
// 添加CORS支持
app.use(
  (0, cors_1.default)({
    origin: "http://localhost:3000", // React开发服务器地址
    credentials: true,
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowHeaders: ["Content-Type", "Authorization", "Accept"],
  })
);
// 添加JSON解析中间件
app.use((0, koa_bodyparser_1.default)());
// 渲染模板
app.context.render = co_1.default.wrap(
  (0, koa_swig_1.default)({
    root: viewDir,
    autoescape: true,
    cache: memoryFlag,
    writeBody: false,
    ext: "html",
  })
);
//如果遇到用户请求 请求container参与实际的调用
app.use((0, awilix_koa_1.scopePerRequest)(container));
//静态资源生效节点
app.use((0, koa_static_1.default)(staticDir));
app.use(
  (0, koa2_connect_history_api_fallback_1.default)({
    index: "/",
    whiteList: ["/api"],
  })
);
//让所有的路由全部自动生效
app.use((0, awilix_koa_1.loadControllers)(`${__dirname}/routers/*.js`));
// 启动服务
if (process.env.NODE_ENV !== "production") {
  const serverPort = 3001; // 使用3001端口避免与React冲突
  app.listen(serverPort, () => {
    console.log(`Fl-Bff Server启动成功，端口: ${serverPort}`);
    console.log(`API地址: http://localhost:${serverPort}/api`);
  });
}
exports.default = app;
